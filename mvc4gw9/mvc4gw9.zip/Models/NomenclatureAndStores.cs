﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.IO;


namespace mvc4gw9.Models
{
    [Table("Nomenclature", Schema="dbo")]
    public class Nomenclature
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
    }

    [Table("FeaturesSets", Schema = "dbo")]
    public class FeaturesSet
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
    }

    [Table("Characteristics", Schema = "dbo")]    
    public class Characteristic
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set;}
    }

    [Table("Stores", Schema = "dbo")]        
    public class Store
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
    }

    [Table("FeaturesOfNomenclatures", Schema = "dbo")]
    public class FeaturesOfNomenclature
    {
        [Key]
        public int Id { get; set; }
        //[ForeignKey("NomenclatureVaiant")]
        public int FeaturesSetId { get; set; }
        //[ForeignKey("Characteristic")]
        public int CharacteristicId { get; set; }
        public string Value { get; set; }

        //public NomenclatureVariant NomenclatureVariant { get; set; }
        //public Characteristic Characteristic { get; set; }
    }


    [Table("NomenclatureInStores", Schema = "dbo")]                
    public class NomenclatureInStore
    {
        [Key]
        public int Id { get; set; }
        //[ForeignKey("Store")]
        public int StoreId { get; set; }
        //[ForeignKey("Nomenclature")]
        public int NomenclatureId { get; set; }
        //[ForeignKey("NomenclatureVariant")]
        public int FeaturesSet { get; set; }
        public int Amount { get; set; }
        public int ReservarionAmount { get; set; }

        //public Store Store { get; set; }
        //public Nomenclature Nomenclature { get; set; }
        //public NomenclatureVariant NomenclatureaVariant { get; set; }
    }

    [Table("NomenclatureViews", Schema = "dbo")]
    public class NomenclatureView
    {
        [Key]
        public int Id { get; set; }
        public int NomenclatureId { get; set; }
        public int FeaturesSetId { get; set; }
        public string Image { get; set; }
    }


    /// //////////////////////////////////////////////////////////////////////////////////////

    public class DAL
    {
        public static Product GetProduct (int NomenclatureId, int FeaturesSetId)
        {
            Product product = new Product();
            List<string> gallery = new List<string>();
            List<Parameter> parametres = new List<Parameter>();
            Parameter colors = new Parameter() { Name = "color" };
            Parameter sizes = new Parameter() { Name = "size" };

            using (DBContext db = new DBContext())
            {
                
                product.Id = NomenclatureId;
                product.Name = db.Nomenclature.Find(NomenclatureId).Name.ToString() + "(" + db.FeaturesSets.Find(FeaturesSetId).Name.ToString() + ")";
                
                int counter=1;
                string path = AppDomain.CurrentDomain.BaseDirectory + @"/Content/nomenclature/pictures_small/";
                string filename = db.NomenclatureViews.FirstOrDefault(x=>x.NomenclatureId==NomenclatureId && x.FeaturesSetId==FeaturesSetId).Image.ToString() + counter + ".jpg";
                
                while (File.Exists(path+filename))
                {
                    gallery.Add(filename);
                    counter++;
                    filename = db.NomenclatureViews.FirstOrDefault(x => x.NomenclatureId == NomenclatureId && x.FeaturesSetId == FeaturesSetId).Image.ToString() + counter + ".jpg";
                }

                product.Gallery = gallery;

                List<string> _colors = new List<string>();
                List<string> _sizes = new List<string>();

                List<int> FeaturesSets = db.NomenclatureInStores.Where(x => x.NomenclatureId == NomenclatureId && x.Amount>0).Select(x => x.FeaturesSet).ToList();
                foreach (var item in FeaturesSets)
                {
                    _colors.AddRange(db.FeaturesOfNomenclatures.Where(x => x.CharacteristicId == 1 && x.FeaturesSetId == item).Select(x => x.Value).ToList());
                    _sizes.AddRange(db.FeaturesOfNomenclatures.Where(x => x.CharacteristicId == 2 && x.FeaturesSetId == item).Select(x => x.Value).ToList());
                }

                for (int i=0; i<_colors.Count; i++)
                {
                    if (colors.Values == null)
                    {
                        colors.Values = new List <string>() { _colors[i]};
                    }
                    else
                    {
                        if (!colors.Values.Exists(x => x == _colors[i])) colors.Values.Add(_colors[i]);
                    }

                }

                for (int i = 0; i < _sizes.Count; i++)
                {
                    if (sizes.Values == null)
                    {
                        sizes.Values = new List<string> { _sizes[i] };
                    }
                    else
                    {
                        if (sizes.Values.FirstOrDefault(x => x == _sizes[i]) == null) sizes.Values.Add(_sizes[i]);
                    }

                }

                parametres.Add(colors);
                parametres.Add(sizes);
                product.Parameters = parametres;
                
                string currentParameters = string.Empty;
                List<Characteristic> characteristics = new List<Characteristic>();
                characteristics = db.Characteristics.ToList();
                foreach (Characteristic charactericstic  in characteristics)
                    currentParameters += charactericstic.Name + "=" + db.FeaturesOfNomenclatures.FirstOrDefault(x=>x.FeaturesSetId == FeaturesSetId && x.CharacteristicId == charactericstic.Id).Value + " ";

                product.currentParameters = currentParameters.Substring(0, currentParameters.Count()-1);
                
            }
            
            return product;
        }


        public static string GetNewCurentParametersString(string parameter, string value, string parametersString)
        {
            string[] parameters = parametersString.Split((char)32);
            int k = parameters.Count();
            string[] parameterName = new string[k];
            string newCurrentParametersString = string.Empty;
            for (int i = 0; i < k; i++)
            {
                parameterName[i] = parameters[i].Split('=')[0];
                if (parameterName[i] == parameter)
                {
                    newCurrentParametersString += parameter + "=" + value;
                }
                else
                {
                    newCurrentParametersString += parameters[i];
                }
            }
            return newCurrentParametersString;
        }


        public static int GetNewFeaturesSetId(string parameter, string value, string parametersString)
        {
            string[] parameters = parametersString.Split((char)32);
            int k = parameters.Count();
            string [] parameterName = new string[k];
            string [] parameterValue = new string[k];
            for (int i = 0; i < k; i++)
            {
                parameterName[i] = parameters[i].Split('=')[0];
                if (parameterName[i] == parameter)
                {
                    parameterValue[i] = value;
                }
                else
                {
                    parameterValue[i] = parameters[i].Split('=')[1];
                }
            }

            List<FeaturesOfNomenclature> featuresOfNomenclature = new List<FeaturesOfNomenclature>();
            List<FeaturesOfNomenclature> featuresOfNomenclature_buffer = new List<FeaturesOfNomenclature>();
            List<FeaturesOfNomenclature> featuresOfNomenclature_add = new List<FeaturesOfNomenclature>();
            List<int> featuresOfNomenclatureId = new List<int>();

            using (DBContext db = new DBContext())
            {
                featuresOfNomenclature = db.FeaturesOfNomenclatures.ToList();

                for (int i=0; i<k; i++)
                {
                    string parametername = parameterName[i];
                    int characteristicId = db.Characteristics.FirstOrDefault(x=>x.Name==parametername).Id;
                    featuresOfNomenclatureId = featuresOfNomenclature.Where(x => x.CharacteristicId == characteristicId && x.Value == parameterValue[i]).Select(x => x.FeaturesSetId).ToList();

                    foreach (int id in featuresOfNomenclatureId)
                    {
                        featuresOfNomenclature_add = featuresOfNomenclature.Where(x => x.FeaturesSetId == id && x.CharacteristicId != characteristicId).ToList();
                        featuresOfNomenclature_buffer.AddRange(featuresOfNomenclature_add);
                    }
                    featuresOfNomenclature = featuresOfNomenclature_buffer;
                }
            }
            return featuresOfNomenclatureId[0];
        }

    }

    public class DBContext :DbContext
    {
        public DbSet<Nomenclature> Nomenclature { get; set; }
        public DbSet<Characteristic> Characteristics { get; set; }
        public DbSet<FeaturesSet> FeaturesSets { get; set; }
        public DbSet<NomenclatureView> NomenclatureViews { get; set; }
        public DbSet<Store> Stores { get; set; }
        public DbSet<FeaturesOfNomenclature> FeaturesOfNomenclatures { get; set; }
        public DbSet<NomenclatureInStore> NomenclatureInStores { get; set; }
    }

    public class DBInitializer : DropCreateDatabaseAlways<DBContext>
    {
        protected override void Seed(DBContext context)
        {
            List<Nomenclature> nomenclature = new List<Nomenclature>() {
                new Nomenclature {Id=1, Name="Boots1"},
                new Nomenclature {Id=2, Name="Boots2"}
            };
            nomenclature.ForEach(x=>context.Nomenclature.Add(x));
            context.SaveChanges();

            List<FeaturesSet> featuressets = new List<FeaturesSet>() {
                new FeaturesSet {Id=1, Name="brown 40"},
                new FeaturesSet {Id=2, Name="brown 41"},
                new FeaturesSet {Id=3, Name="yellow 40"}, 
                new FeaturesSet {Id=4, Name="yellow 41"},
                new FeaturesSet {Id=5, Name="white 40"},
            };
            featuressets.ForEach(x => context.FeaturesSets.Add(x));
            context.SaveChanges();

            List<Characteristic> characteristics = new List<Characteristic>()
            {
                new Characteristic {Id=1, Name="color"},
                new Characteristic {Id=2, Name="size"}
            };
            characteristics.ForEach(x => context.Characteristics.Add(x));
            context.SaveChanges();

            List<FeaturesOfNomenclature> featuresofnumenclatures = new List<FeaturesOfNomenclature>()
            {
                new FeaturesOfNomenclature {Id=1, FeaturesSetId=1, CharacteristicId=1, Value="brown"},
                new FeaturesOfNomenclature {Id=2, FeaturesSetId=1, CharacteristicId=2, Value="40"},
                new FeaturesOfNomenclature {Id=3, FeaturesSetId=2, CharacteristicId=1, Value="brown"},
                new FeaturesOfNomenclature {Id=4, FeaturesSetId=2, CharacteristicId=2, Value="41"},
                new FeaturesOfNomenclature {Id=5, FeaturesSetId=3, CharacteristicId=1, Value="yellow"},
                new FeaturesOfNomenclature {Id=6, FeaturesSetId=3, CharacteristicId=2, Value="40"},
                new FeaturesOfNomenclature {Id=7, FeaturesSetId=4, CharacteristicId=1, Value="yellow"},
                new FeaturesOfNomenclature {Id=8, FeaturesSetId=4, CharacteristicId=2, Value="41"},
                new FeaturesOfNomenclature {Id=9, FeaturesSetId=5, CharacteristicId=1, Value="white"},
                new FeaturesOfNomenclature {Id=10, FeaturesSetId=5, CharacteristicId=2, Value="40"}
            };
            featuresofnumenclatures.ForEach(x => context.FeaturesOfNomenclatures.Add(x));
            context.SaveChanges();


            List<NomenclatureView> nomenclatureviews = new List<NomenclatureView>()
            {
                new NomenclatureView {Id=1, NomenclatureId=1, FeaturesSetId=1, Image="boots1_brown"},
                new NomenclatureView {Id=1, NomenclatureId=1, FeaturesSetId=2, Image="boots1_brown"},
                new NomenclatureView {Id=1, NomenclatureId=1, FeaturesSetId=3, Image="boots1_yellow"},
                new NomenclatureView {Id=1, NomenclatureId=1, FeaturesSetId=4, Image="boots1_yellow"},
                new NomenclatureView {Id=1, NomenclatureId=2, FeaturesSetId=5, Image="boots2_white"},
            };

            nomenclatureviews.ForEach(x => context.NomenclatureViews.Add(x));
            context.SaveChanges();

            List<Store> stores = new List<Store> () 
            {
                new Store {Id=1, Name="Main"},
                new Store {Id=2, Name="Sub1"},
                new Store {Id=3, Name="Sub2"}
            };
            stores.ForEach(x=> context.Stores.Add(x));
            context.SaveChanges();

            List<NomenclatureInStore> nomenclatureinstores = new List<NomenclatureInStore> () 
            {
                new NomenclatureInStore {Id=1, StoreId=1, NomenclatureId=1, FeaturesSet=1, Amount=7},
                new NomenclatureInStore {Id=2, StoreId=1, NomenclatureId=1, FeaturesSet=2, Amount=5},
                new NomenclatureInStore {Id=3, StoreId=1, NomenclatureId=1, FeaturesSet=3, Amount=10},
                new NomenclatureInStore {Id=4, StoreId=1, NomenclatureId=1, FeaturesSet=4, Amount=2},

                new NomenclatureInStore {Id=5, StoreId=2, NomenclatureId=1, FeaturesSet=1, Amount=2},
                new NomenclatureInStore {Id=6, StoreId=2, NomenclatureId=1, FeaturesSet=2, Amount=0},
                new NomenclatureInStore {Id=7, StoreId=2, NomenclatureId=1, FeaturesSet=3, Amount=11},
                new NomenclatureInStore {Id=8, StoreId=2, NomenclatureId=1, FeaturesSet=4, Amount=8},

                new NomenclatureInStore {Id=9, StoreId=1, NomenclatureId=2, FeaturesSet=1, Amount=4},
                new NomenclatureInStore {Id=10, StoreId=1, NomenclatureId=2, FeaturesSet=2, Amount=8},
                new NomenclatureInStore {Id=11, StoreId=1, NomenclatureId=2, FeaturesSet=3, Amount=0},
                new NomenclatureInStore {Id=12, StoreId=1, NomenclatureId=2, FeaturesSet=4, Amount=3},

                new NomenclatureInStore {Id=13, StoreId=3, NomenclatureId=2, FeaturesSet=1, Amount=12},
                new NomenclatureInStore {Id=14, StoreId=3, NomenclatureId=2, FeaturesSet=2, Amount=6},
                new NomenclatureInStore {Id=15, StoreId=3, NomenclatureId=2, FeaturesSet=3, Amount=0},
                new NomenclatureInStore {Id=16, StoreId=3, NomenclatureId=2, FeaturesSet=4, Amount=3},
            };
            nomenclatureinstores.ForEach(x=> context.NomenclatureInStores.Add(x));
            context.SaveChanges();
        }
    }
} 



