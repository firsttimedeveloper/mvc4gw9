﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using mvc4gw9.Models;

namespace mvc4gw9.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            Product product = new Product();
            product = DAL.GetProduct(1, 1);
            return View(product);
        }

        public ActionResult product_changeImage(string filename)
        {
            return PartialView("product_changeImage", filename);
        }


        public PartialViewResult product_changeParameter(int nomenclatureId, string parameter, string value, string currentParameters)
        {
            Product product= new Product();

            product = DAL.GetProduct(nomenclatureId, DAL.GetNewFeaturesSetId(parameter, value, currentParameters));

            return PartialView("product_changeParameter", product);
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
